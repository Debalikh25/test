package com.patient.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.patient.exception.PatientDetailsException;
import com.patient.model.PatientDetails;
import com.patient.repository.PatientDetailsRepository;
import com.patient.service.PatientDetailsService;
import com.patientdao.Response;

@RestController
@CrossOrigin("*")
public class PatientDetailsController {

	@Autowired
	PatientDetailsService patientDetailsService;
	
	@Autowired
	private PatientDetailsRepository patientDetailsRepository;
	
	private Response response = new Response();

	@PostMapping("/load/patientdata")
	public List<PatientDetailsException> uploadPatientDetails(@RequestParam("file") MultipartFile excel)
			throws IOException {
		List<PatientDetailsException> detailsExceptions = new ArrayList<>();
		if (!excel.isEmpty()) {
			detailsExceptions = patientDetailsService.savePatientDetails(excel);
			if (detailsExceptions.isEmpty()) {
				PatientDetailsException exceptio = new PatientDetailsException();
				exceptio.setExceptionMessage("File Uploaded successfully");
				detailsExceptions.add(exceptio);
			}
		} else {
			PatientDetailsException exceptio = new PatientDetailsException();
			exceptio.setExceptionMessage("Please Upload Excel file");
		}
		return detailsExceptions;
	}
	

	
	@GetMapping("/load/retrieve/{patientName}")
  public ResponseEntity<?> getpatientByName(@PathVariable String patientName) {
		
		 
		
		PatientDetails patientDetails=patientDetailsService.getPatientByName(patientName);
		if(patientDetails != null) {
			return new ResponseEntity<>(patientDetails, HttpStatus.OK);
		}
		response.setResponse("Record not available with Patient Name = "+patientName);
		response.setStatus(404);
		return new ResponseEntity<Response>(response , HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/get/patient/{id}")
	public ResponseEntity<?> getPatientById(@PathVariable("id") Integer id){
		  
		 PatientDetails p = this.patientDetailsService.getPatientById(id);
		 if(p == null) {
			 response.setStatus(404);
			 response.setResponse("Record not available for patient with id "+ id);
			 return new ResponseEntity<Response>(response , HttpStatus.NOT_FOUND);
			 
		 }
		 
		 return new ResponseEntity<PatientDetails>(p , HttpStatus.OK);
		
	}
	
	@PutMapping("/load/updatepatient")
	public  ResponseEntity<?> updatePatientDetails(@RequestBody PatientDetails patientDetails){
		if(null!=patientDetailsService.updatePatientDetails(patientDetails)) {
			return new ResponseEntity<>(patientDetailsService.updatePatientDetails(patientDetails), HttpStatus.OK);
		}
		return new ResponseEntity<String>("Patient Details not updated", HttpStatus.NOT_FOUND);
	}
	
    @PutMapping("/process/patient")
	public ResponseEntity<?> processPatient(@RequestBody PatientDetails patientDetails){
    { patientDetails.setStatus("Processed");
    PatientDetails save = this.patientDetailsRepository.save(patientDetails);
    return new ResponseEntity<>(save , HttpStatus.OK);
    }
   }
    
 }
